package com.wkclz.util.excelRd;

public class ExcelRdException extends Exception {
	
	/** 
	* @Fields serialVersionUID : TODO(用一句话描述这个变量表示什么) 
	* @author wangkc admin@wkclz.com  
	* @date 2017年7月19日 上午11:12:23 * 
	*/ 
	
	private static final long serialVersionUID = 1L;

	public ExcelRdException(String msg) {
		super(msg);
	}
}
