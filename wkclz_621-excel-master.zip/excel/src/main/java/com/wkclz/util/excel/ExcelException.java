package com.wkclz.util.excel;

public class ExcelException extends Exception {

	/**
	* @Fields serialVersionUID
	* @author wangkc admin@wkclz.com
	* @date 2017年12月09日 上午09:27:55 *
	*/

	public ExcelException(String msg) {
		super(msg);
	}
}
